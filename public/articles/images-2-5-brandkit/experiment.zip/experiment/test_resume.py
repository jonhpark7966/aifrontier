"""No-network regression checks for ambiguous paid-request outcomes."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import run

class ResumeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        (self.root/'logs').mkdir()
        self.root_patch=patch.object(run,'ROOT',self.root)
        self.root_patch.start()
        self.key_patch=patch.object(run,'key',return_value='test-only-placeholder')
        self.key_patch.start()

    def tearDown(self):
        self.key_patch.stop();self.root_patch.stop();self.temp.cleanup()

    def test_timeout_cannot_dispatch_again(self):
        with patch.object(run.urllib.request,'urlopen',side_effect=TimeoutError) as network:
            with self.assertRaises(RuntimeError):run.call('stage','test')
            request=(self.root/'logs/stage.request.json').read_bytes()
            with self.assertRaises(RuntimeError):run.call('stage','test')
            self.assertEqual(network.call_count,1)
            self.assertEqual((self.root/'logs/stage.request.json').read_bytes(),request)
        result=json.loads((self.root/'logs/stage.json').read_text())
        self.assertEqual(result['status'],'unknown_outcome')
        self.assertIsNone(result['usage'])

    def test_request_only_record_blocks_dispatch(self):
        (self.root/'logs/stage.request.json').write_text('{}')
        with patch.object(run.urllib.request,'urlopen') as network:
            with self.assertRaises(RuntimeError):run.call('stage','test')
            network.assert_not_called()

    def test_completed_response_is_reused(self):
        result={'status':'completed','usage':{'input_tokens':1}}
        (self.root/'logs/stage.json').write_text(json.dumps(result))
        with patch.object(run.urllib.request,'urlopen') as network:
            self.assertEqual(run.call('stage','test'),result)
            network.assert_not_called()

if __name__=='__main__':unittest.main()
