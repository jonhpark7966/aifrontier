"""Recalculate published metrics from sanitized records. No API calls."""
import json
import math
from pathlib import Path
ROOT=Path(__file__).resolve().parent
records=ROOT/'records'
if not records.exists():records=ROOT
astra=image_output=0
for file in sorted((records/'logs').glob('*.json')):
    if file.name.endswith('.request.json'):continue
    d=json.loads(file.read_text());u=d.get('usage')
    if not u:
        print(file.name,'UNPRICED: no reported usage');continue
    detail=u['input_tokens_details'];cached=detail.get('cached_tokens',0);writes=detail.get('cache_write_tokens',0)
    cost=((u['input_tokens']-cached-writes)*10+cached+writes*12.5+u['output_tokens']*50)/1e6
    astra+=cost
    images=d.get('image_calls',d.get('output',[]));estimated=0
    for i in images:
        if i.get('type')!='image_generation_call':continue
        w,h=map(int,i['size'].split('x'));slots={'low':16,'medium':24,'high':48,'xhigh':64,'max':96}[i['quality']]
        tokens=math.ceil(slots*round(slots/(max(w,h)/min(w,h)))*(2000000+w*h)/4000000)
        estimated+=tokens*30/1e6
    image_output+=estimated
    print(file.stem,'Astra',round(cost,7),'image output ESTIMATE',round(estimated,7))
print('Astra usage-based USD:',round(astra,7))
print('Image output ESTIMATED USD:',round(image_output,7))
print('Combined subtotal excluding UNKNOWN image inputs:',round(astra+image_output,7))
print('NOT a complete billed total. Rates snapshot: pricing-snapshot.json')

