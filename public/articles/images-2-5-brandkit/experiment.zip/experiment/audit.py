"""Recreate pixel/display evidence; optional --evaluate makes one paid Astra call."""
import argparse
import json
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import run

parser=argparse.ArgumentParser()
parser.add_argument('--evaluate',action='store_true')
args=parser.parse_args()
root=Path(__file__).resolve().parent
records=root/'records' if (root/'records/images').exists() else root
audit=root/'audit';audit.mkdir(exist_ok=True)
results=[]
for name in ('02-concept-A-1.png','04-canonical-1.png'):
    im=Image.open(records/'images'/name).convert('RGBA');spans=[];start=None
    for x in range(im.width+1):
        hit=False
        if x<im.width:
            r,g,b,a=im.getpixel((x,512));hit=a>=128 and max(r,g,b)<80
        if hit and start is None:start=x
        if not hit and start is not None:
            spans.append({'start':start,'end':x-1,'width':x-start});start=None
    results.append({'file':name,'row_y':512,'threshold':'alpha >=128 and max RGB <80','dark_spans':spans})
(audit/'pixel-audit-reproduced.json').write_text(json.dumps(results,indent=2))
for label,name in [('canonical','04-canonical-1.png'),('before','06-wordmark-1.png'),('after','08-repair-wordmark-1.png')]:
    im=Image.open(records/'images'/name).convert('RGBA');bg=Image.new('RGBA',im.size,'white');bg.alpha_composite(im);bg.convert('RGB').save(audit/(label+'-on-white.png'))
im=Image.open(records/'images/04-canonical-1.png').convert('RGBA');sheet=Image.new('RGBA',(600,180),'white');draw=ImageDraw.Draw(sheet)
try:font=ImageFont.truetype('/System/Library/Fonts/Helvetica.ttc',16)
except OSError:font=ImageFont.load_default(size=16)
for x,n in [(20,32),(120,64),(280,128)]:
    sheet.alpha_composite(im.resize((n,n),Image.Resampling.LANCZOS),(x,40));draw.text((x,12),str(n)+' px',font=font,fill='black')
sheet.convert('RGB').save(audit/'native-sizes.png')
print(json.dumps(results,indent=2))
if args.evaluate:
    stage=json.loads((records/'logs/10-display-audit.request.json').read_text())['stage']
    run.ROOT=audit
    for d in ('logs','decisions','images'):(audit/d).mkdir(exist_ok=True)
    run.decision('10-display-audit',stage,[audit/'canonical-on-white.png',audit/'before-on-white.png',audit/'after-on-white.png',audit/'native-sizes.png'])
