Reproduce generation: Python 3, OPENAI_API_KEY in the environment, python3 run.py. Paid API calls will be made.
One human brief; fixed stage prompts in run.py; 30-request cap; unresolved requests block resubmission.
Published evidence, including all 15 original PNGs, is in records/. A fresh run creates logs/, decisions/ and images/ separately.
Recalculate costs without network: python3 recalculate.py. Includes the separate display audit.
Recreate pixel counts and display composites: install Pillow, then python3 audit.py. No API call by default. Add --evaluate only to make one new paid Astra evaluation.
Regression checks without network: python3 test_resume.py.
Final selected outputs and size variants are also provided in brandkit.zip.
Metrics distinguish reported Astra tokens from estimated image output tokens. Complete billed cost is unavailable.
Current pricing source: https://developers.openai.com/api/docs/pricing.md (retrieved 2026-09-09); see pricing-snapshot.json.
