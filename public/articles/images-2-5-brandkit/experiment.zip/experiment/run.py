"""One human brief, fixed stages, Astra-authored creative decisions.

Uses the Responses API's native image_generation tool, not a mocked tool.
No automatic HTTP retries: an ambiguous timeout must be accounted for.
"""
import base64
import json
import os
import re
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for folder in ('logs', 'images', 'decisions'):
    (ROOT / folder).mkdir(exist_ok=True)
BRIEF = (ROOT / 'brief.txt').read_text()
MODEL = 'gpt-6-astra'
IMAGE_MODEL = 'gpt-image-2.5-flare'


def key():
    if os.environ.get('OPENAI_API_KEY'):
        return os.environ['OPENAI_API_KEY']
    env = Path(os.environ.get('OPENAI_KEY_FILE', '.env'))
    for line in env.read_text().splitlines():
        match = re.match(r'(?:export\s+)?OPENAI_API_KEY\s*=\s*(.*)', line)
        if match:
            return match[1].strip().strip('\"\'')
    raise RuntimeError('OPENAI_API_KEY is missing')


def content(text, images=()):
    items = [{'type': 'input_text', 'text': text}]
    for path in images:
        path = Path(path)
        mime = 'image/jpeg' if path.suffix == '.jpg' else 'image/png'
        items.extend([{'type': 'input_text', 'text': 'Reference filename: ' + path.name},
                      {'type': 'input_image', 'image_url': 'data:' + mime + ';base64,' + base64.b64encode(path.read_bytes()).decode()}])
    return items


def call(name, text, images=(), generation=False, size='1024x1024', transparent=False):
    cached = ROOT / 'logs' / (name + '.json')
    if cached.exists():
        data = json.loads(cached.read_text())
        if data.get('status') == 'completed':
            return data
        raise RuntimeError(f'{name} already attempted; inspect its log before retrying')
    request_log = ROOT / 'logs' / (name + '.request.json')
    if request_log.exists():
        raise RuntimeError(f'{name} has an unresolved request; reconcile it before any new paid call')
    if len(list((ROOT/'logs').glob('*.request.json'))) >= 30:
        raise RuntimeError('30-request run limit reached')
    body = {'model': MODEL, 'instructions': 'You are the autonomous brand designer and visual reviewer in the attached experiment. Follow the single human brief. Stage messages are predetermined controller instructions, not new human preferences. Never claim to see an image unless it is supplied. Provide concise public design rationale, not hidden chain of thought.',
            'input': [{'role': 'user', 'content': content(BRIEF + '\n\nAUTOMATED STAGE:\n' + text, images)}],
            'reasoning': {'effort': 'medium'}, 'max_output_tokens': 6000}
    if generation:
        body.update(tools=[{'type': 'image_generation', 'model': IMAGE_MODEL, 'size': size, 'quality': 'high', 'output_format': 'png', 'background': 'transparent' if transparent else 'opaque'}], tool_choice={'type': 'image_generation'})
    else:
        body['text'] = {'format': {'type': 'json_object'}}
    safe_request = {'stage': text, 'references': [str(Path(p).relative_to(ROOT)) for p in images],
                    'model': MODEL, 'tools': body.get('tools'), 'reasoning': body['reasoning'], 'max_output_tokens': body['max_output_tokens']}
    # Exclusive creation also prevents two runners from dispatching the same stage.
    with request_log.open('x') as f:
        json.dump(safe_request, f, ensure_ascii=False, indent=2)
    started = time.time()
    cached.write_text(json.dumps({'status':'pending','experiment':{'stage':name,'started_at':datetime.fromtimestamp(started,timezone.utc).isoformat()},'usage':None}))
    print('START', name, datetime.now(timezone.utc).isoformat(), flush=True)
    request = urllib.request.Request('https://api.openai.com/v1/responses', data=json.dumps(body).encode(), headers={'Authorization': 'Bearer '+key(), 'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(request, timeout=600) as response:
            data = json.load(response)
    except urllib.error.HTTPError as exc:
        error = exc.read().decode().replace(key(), '[REDACTED]')
        cached.write_text(json.dumps({'status':'http_error','http_status':exc.code,'error':error,'elapsed_seconds':time.time()-started},indent=2))
        raise RuntimeError(f'{name}: HTTP {exc.code}: {error}') from None
    except (TimeoutError, OSError, ValueError) as exc:
        cached.write_text(json.dumps({'status':'unknown_outcome','error_type':type(exc).__name__,'elapsed_seconds':time.time()-started,'usage':None},indent=2))
        raise RuntimeError(f'{name}: outcome unknown; preserved the attempt and will not resubmit on restart') from None
    data['experiment'] = {'started_at':datetime.fromtimestamp(started,timezone.utc).isoformat(), 'elapsed_seconds':round(time.time()-started,3), 'stage':name}
    image_count = 0
    for item in data.get('output', []):
        if item.get('type') == 'image_generation_call' and item.get('result'):
            image_count += 1
            filename = f'{name}-{image_count}.png'
            (ROOT/'images'/filename).write_bytes(base64.b64decode(item['result']))
            item['result'] = 'images/'+filename
        if item.get('type') == 'reasoning':
            item.pop('encrypted_content', None)
    cached.write_text(json.dumps(data,ensure_ascii=False,indent=2))
    print('DONE',name,'seconds',data['experiment']['elapsed_seconds'],'images',image_count,'usage',data.get('usage'), flush=True)
    if data.get('status') != 'completed':
        raise RuntimeError(f'{name}: incomplete response; preserved usage and images')
    if generation and image_count != 1:
        raise RuntimeError(f'{name}: expected one image, received {image_count}')
    return data


def decision(name, text, images=()):
    response = call(name, text + '\nReturn JSON only.', images)
    result = json.loads(''.join(part['text'] for item in response['output'] if item['type']=='message' for part in item['content'] if part['type']=='output_text'))
    (ROOT/'decisions'/(name+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
    return result


def generate(name, prompt, images=(), size='1024x1024', transparent=False):
    call(name, 'Generate exactly ONE image now using the native image_generation tool. '+prompt, images,True,size,transparent)
    return ROOT/'images'/(name+'-1.png')


def run():
    startfile=ROOT/'run-start.json'
    if not startfile.exists():
        startfile.write_text(json.dumps({'started_at':datetime.now(timezone.utc).isoformat()}))
    refs=sorted((ROOT/'refs').glob('channel-*.jpg'))
    plan=decision('01-plan', 'Plan four genuinely distinct logo concepts. Do not choose a winner before seeing actual images. Each image is a single symbol on off-white, no wordmark or captions. Return {"brand_reading_ko":string,"concepts":[{"id":"A" through "D","name_ko":string,"idea_ko":string,"image_prompt_en":string}]}. Each prompt should be specific, polished, and self-contained. Respect the brief, choose your own art direction.',refs)
    if len(plan['concepts']) != 4: raise RuntimeError('Expected four concepts')
    if sorted(c['id'] for c in plan['concepts']) != list('ABCD'):
        raise RuntimeError('Expected unique concept IDs A, B, C, D')
    plan['concepts'].sort(key=lambda c:c['id'])
    concepts=[]
    for c in plan['concepts']:
        concepts.append(generate('02-concept-'+c['id'],c['image_prompt_en']))
    selection=decision('03-selection', 'Visually inspect these four actual images, in A,B,C,D order. Score each criterion 0-10 using the brief weights. Pick one winner; do not compromise or combine concepts. Return {"scores":[{"id":string,"brand":number,"small_size":number,"distinctiveness":number,"merch":number,"rationale_ko":string}],"winner":string,"selection_reason_ko":string,"weakness_ko":string,"refinement_prompt_en":string}. Refinement must produce ONLY the selected logo mark, transparent PNG, centered with generous clearspace. Preserve identity, simplify weaknesses. Concept descriptions: '+json.dumps(plan,ensure_ascii=False),concepts)
    winner=selection['winner']
    if winner not in 'ABCD' or len(winner)!=1: raise RuntimeError('Invalid winner')
    canonical=generate('04-canonical',selection['refinement_prompt_en'],[concepts['ABCD'.index(winner)]],transparent=True)
    kit=decision('05-kit-plan', 'Inspect the canonical image and plan a coherent kit based on its actual geometry and color. Return {"canonical_review_ko":string,"brand_name":string,"palette":[{"hex":string,"role_ko":string}],"type_direction_ko":string,"invariants_ko":[string],"assets":[{"id":string,"purpose_ko":string,"image_prompt_en":string}]}. Exactly these nine asset IDs: moodboard,wordmark,banner,thumbnail,tshirt,cap,stickers,keyring,keycaps. Use standalone layouts, not a collage of all requested products. moodboard may be an editorial contact board with colors, type and materials. wordmark is a flat horizontal brand lockup on transparent background; banner is a wide web hero with generous safe area; thumbnail must have the exact Korean headline "AI가 브랜드를 만든다면" and AI Frontier KR. Other five are distinct photoreal product mockups. Do not redraw or reinterpret the canonical symbol. Prompts must describe placement, identity constraints, materials and typography. Offer a premium, distinctive yet welcoming identity, not generic tech swag.',[canonical])
    required=['moodboard','wordmark','banner','thumbnail','tshirt','cap','stickers','keyring','keycaps']
    if sorted(a['id'] for a in kit['assets']) != sorted(required): raise RuntimeError('Unexpected assets')
    assets=[]
    for a in kit['assets']:
        size='1536x1024' if a['id'] not in ('banner','thumbnail','wordmark') else '1536x864'
        assets.append(generate('06-'+a['id'], a['image_prompt_en']+' The attached canonical mark is the exact source of truth. Preserve its geometry, count of parts, negative spaces, orientation and relative proportions. Do not add or remove components.',[canonical],size,a['id']=='wordmark'))
    review=decision('07-review', 'Inspect canonical first, then the nine assets. Asset order: '+', '.join(a['id'] for a in kit['assets'])+'. Return {"assets":[{"id":string,"consistency_score":number,"verdict_ko":string,"visible_defects_ko":[string]}],"repair_id":string,"repair_reason_ko":string,"repair_prompt_en":string,"limitations_ko":[string]}. Score 0-10 conservatively. Choose exactly ONE weakest non-moodboard asset for a repair; preserve everything already correct and fix visible failures. Do not invent success. In addition to geometry, examine legibility and realistic use of materials.',[canonical]+assets)
    repairid=review['repair_id']
    if repairid not in required or repairid=='moodboard': raise RuntimeError('Invalid repair asset')
    original=assets[[a['id'] for a in kit['assets']].index(repairid)]
    repair=generate('08-repair-'+repairid,review['repair_prompt_en']+' Reference 1 is the canonical master; reference 2 is the previous asset to repair.',[canonical,original], '1536x864' if repairid in ('banner','thumbnail','wordmark') else '1536x1024', repairid=='wordmark')
    final=decision('09-final-review', 'Compare canonical, before, after in that order. Return {"asset_id":string,"before_score":number,"after_score":number,"keep":"before" or "after","reason_ko":string,"remaining_defects_ko":[string],"experiment_conclusion_ko":string}. Reject the repair if it is worse. This is a subjective visual audit, not evidence of model training or weight updates. Asset ID: '+repairid,[canonical,original,repair])
    (ROOT/'run-finish.json').write_text(json.dumps({'finished_at':datetime.now(timezone.utc).isoformat(),'selected_concept':winner,'repair_id':repairid,'keep':final['keep']},indent=2))


if __name__=='__main__':
    run()
